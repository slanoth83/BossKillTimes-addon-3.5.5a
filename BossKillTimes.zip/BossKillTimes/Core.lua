SLASH_BOSSKILLTIMES1 = "/bkt"
SLASH_BOSSKILLTIMES2 = "/bosskills"

SlashCmdList["BOSSKILLTIMES"] = function(msg)
    local args = {}
    for word in msg:gmatch("%S+") do 
        table.insert(args, word) 
    end

    -- Jos komento annetaan tyhjänä, näytetään tai piilotetaan UI-ikkuna
    if #args == 0 then
        if BossKillTimesUI:IsShown() then
            BossKillTimesUI:Hide()
        else
            BossKillTimesUI:Show()
        end
        return
    end

    -- Vanha haku chatin kautta toimii edelleen, jos käyttäjä kirjoittaa bossin nimen
    local bossName = table.concat(args, " ")
    bossName = string.gsub(bossName, "´", "'")
    bossName = string.gsub(bossName, "`", "'")
    
    local searchName = string.lower(bossName)
    local found = false

    for zone, bosses in pairs(BossKillTimesDB) do
        for dbBossName, records in pairs(bosses) do
            if string.lower(dbBossName) == searchName then
                print("|cFF00FFFFTop Kill Times for " .. dbBossName .. ":|r")
                for i, record in ipairs(records) do
                    if i <= 5 then
                        print("|cFFFFFF00" .. record.rank .. ".|r " .. record.guild .. " (" .. record.mode .. ") - |cFF00FF00" .. record.time .. "|r [" .. record.date .. "]")
                    end
                end
                found = true
                break
            end
        end
        if found then break end
    end

    if not found then
        print("|cFFFF0000No data found for:|r " .. bossName)
    end
end