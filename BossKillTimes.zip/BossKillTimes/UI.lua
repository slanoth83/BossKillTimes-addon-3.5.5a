-- Pääikkuna (tummennettu ja läpinäkymätön tausta)
local frame = CreateFrame("Frame", "BossKillTimesUI", UIParent)
frame:SetSize(400, 450) 
frame:SetPoint("CENTER")
frame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground", 
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 }
})
frame:SetBackdropColor(0, 0, 0, 0.95) 
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

-- Otsikko
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
title:SetPoint("TOP", 0, -15)
title:SetText("Boss Kill Times (Top 100)")

-- Sulkemispainike
local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -5, -5)

-- Päivitysaika
local updateText = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
updateText:SetPoint("TOPRIGHT", -25, -45)
updateText:SetJustifyH("RIGHT")
if BossKillTimesLastUpdated then
    updateText:SetText("Updated: " .. BossKillTimesLastUpdated)
else
    updateText:SetText("Updated: N/A")
end

-- Pudotusvalikko
local dropdown = CreateFrame("Frame", "BKT_BossDropdown", frame, "UIDropDownMenuTemplate")
dropdown:SetPoint("TOPLEFT", 10, -40)

-- Tilan valintapainike (10 Man / 25 Man)
local currentMode = "25m"
local modeButton = CreateFrame("Button", "BKT_ModeButton", frame, "UIPanelButtonTemplate")
modeButton:SetSize(80, 22)
-- UUSI SIJAINTI: X-napin vasemmalle puolelle
modeButton:SetPoint("RIGHT", closeBtn, "LEFT", 5, 0)
modeButton:SetText("25 Man")

-- Killan oma paras aika (Weedsmokers)
local guildBestTitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
guildBestTitle:SetPoint("TOPLEFT", 40, -80)
guildBestTitle:SetJustifyH("LEFT")
guildBestTitle:SetText("Guild best time: Weedsmokers - N/A")

-------------------------------------------------
-- Vierityspalkki ja sen sisältöalue (ScrollFrame)
-------------------------------------------------
local scrollFrame = CreateFrame("ScrollFrame", "BKT_ScrollFrame", frame, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 20, -110)
scrollFrame:SetPoint("BOTTOMRIGHT", -35, 15)

local scrollChild = CreateFrame("Frame", "BKT_ScrollChild", scrollFrame)
scrollChild:SetSize(scrollFrame:GetWidth(), 100) 
scrollFrame:SetScrollChild(scrollChild)

-- Luodaan 100 tekstiriviä valmiiksi
local lines = {}
for i = 1, 100 do
    local line = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    line:SetPoint("TOPLEFT", 10, -(i - 1) * 20) 
    line:SetJustifyH("LEFT")
    line:SetText("")
    lines[i] = line
end

-- Funktio, joka päivittää datan ruudulle
local function RefreshBossData(bossName)
    if not bossName or bossName == "Select a Boss" then return end

    for i = 1, 100 do lines[i]:SetText("") end
    
    local targetGuild = "Weedsmokers"
    local guildFound = false
    local recordCount = 0

    if BossKillTimesDB and BossKillTimesDB[currentMode] and BossKillTimesDB[currentMode]["Bosses"][bossName] then
        for i, record in ipairs(BossKillTimesDB[currentMode]["Bosses"][bossName]) do
            if i <= 100 then
                local rankText = "|cFFFFFF00" .. record.rank .. ".|r "
                local timeText = "|cFF00FF00" .. record.time .. "|r "
                local isTarget = (string.lower(record.guild) == string.lower(targetGuild))
                
                local displayMode = (currentMode == "25m") and "25 man" or "10 man"

                if isTarget then
                    lines[i]:SetText(rankText .. "|cFFFF55FF" .. record.guild .. " (" .. displayMode .. ")|r - " .. timeText .. "|cFFFF55FF[" .. record.date .. "]|r")
                    guildBestTitle:SetText("Guild best time: Weedsmokers - " .. timeText .. " (Rank " .. record.rank .. ")")
                    guildFound = true
                else
                    lines[i]:SetText(rankText .. record.guild .. " (" .. displayMode .. ") - " .. timeText .. "[" .. record.date .. "]")
                end
                
                recordCount = i
            end
        end
    else
        lines[1]:SetText("|cFFFF0000No data found for this boss.|r")
        recordCount = 1
    end

    if not guildFound then
        guildBestTitle:SetText("Guild best time: Weedsmokers - |cFF999999Not in Top 100|r")
    end

    scrollChild:SetHeight(math.max(recordCount * 20, 20))
end

-- Pudotusvalikon valinta
local function OnClick(self)
    UIDropDownMenu_SetSelectedID(BKT_BossDropdown, self:GetID())
    RefreshBossData(self.value)
end

-- Mode-painikkeen logiikka
modeButton:SetScript("OnClick", function(self)
    if currentMode == "25m" then
        currentMode = "10m"
        self:SetText("10 Man")
    else
        currentMode = "25m"
        self:SetText("25 Man")
    end
    
    -- Päivitetään lista automaattisesti jos jokin boss on jo valittuna
    local selectedBoss = UIDropDownMenu_GetText(BKT_BossDropdown)
    RefreshBossData(selectedBoss)
end)

local function InitializeDropdown(self, level)
    local info = UIDropDownMenu_CreateInfo()
    local bosses = {
        "Anub'Rekhan", "Grand Widow Faerlina", "Maexxna",
        "Noth the Plaguebringer", "Heigan the Unclean", "Loatheb",
        "Patchwerk", "Grobbulus", "Gluth", "Thaddius",
        "Instructor Razuvious", "Gothik the Harvester", "The Four Horsemen",
        "Sapphiron", "Kel'Thuzad",
        "Sartharion", "Malygos", "Archavon the Stone Watcher"
    }
    
    for k, v in ipairs(bosses) do
        info = UIDropDownMenu_CreateInfo()
        info.text = v
        info.value = v
        info.func = OnClick
        UIDropDownMenu_AddButton(info, level)
    end
end

UIDropDownMenu_Initialize(BKT_BossDropdown, InitializeDropdown)
UIDropDownMenu_SetWidth(BKT_BossDropdown, 160)
UIDropDownMenu_SetButtonWidth(BKT_BossDropdown, 184)
UIDropDownMenu_SetText(BKT_BossDropdown, "Select a Boss")
UIDropDownMenu_JustifyText(BKT_BossDropdown, "LEFT")

-------------------------------------------------
-- Minimap Button (Draggable, Lockable & Timer Icon)
-------------------------------------------------
local isMinimapLocked = false

local minimapBtn = CreateFrame("Button", "BKT_MinimapButton", Minimap)
minimapBtn:SetSize(32, 32)
minimapBtn:SetMovable(true)
minimapBtn:EnableMouse(true)
minimapBtn:RegisterForDrag("LeftButton")
minimapBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
minimapBtn:SetFrameStrata("MEDIUM")

local icon = minimapBtn:CreateTexture(nil, "BACKGROUND")
icon:SetTexture("Interface\\Icons\\Spell_Nature_TimeStop") 
icon:SetSize(21, 21)
icon:SetPoint("CENTER", minimapBtn, "CENTER", 0, 0)

local border = minimapBtn:CreateTexture(nil, "OVERLAY")
border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
border:SetSize(54, 54)
border:SetPoint("TOPLEFT", minimapBtn, "TOPLEFT", 0, 0)

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:SetScript("OnEvent", function(self, event, addonName)
    if addonName == "BossKillTimes" then
        if type(BossKillTimesSettings) ~= "table" then
            BossKillTimesSettings = {
                minimapAngle = 225, 
                isLocked = false    
            }
        end

        isMinimapLocked = BossKillTimesSettings.isLocked

        local radius = 80
        local angle = BossKillTimesSettings.minimapAngle
        local x = math.cos(math.rad(angle)) * radius
        local y = math.sin(math.rad(angle)) * radius
        minimapBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
    end
end)

minimapBtn:SetScript("OnDragStart", function(self)
    if isMinimapLocked then return end
    
    self:LockHighlight()
    self:SetScript("OnUpdate", function(self)
        local xpos, ypos = GetCursorPosition()
        local xmin, ymin = Minimap:GetLeft(), Minimap:GetBottom()

        xpos = xpos / UIParent:GetScale() - xmin - (Minimap:GetWidth() / 2)
        ypos = ypos / UIParent:GetScale() - ymin - (Minimap:GetHeight() / 2)

        local angle = math.deg(math.atan2(ypos, xpos))
        local radius = 80 

        local x = math.cos(math.rad(angle)) * radius
        local y = math.sin(math.rad(angle)) * radius
        self:SetPoint("CENTER", Minimap, "CENTER", x, y)
    end)
end)

minimapBtn:SetScript("OnDragStop", function(self)
    self:UnlockHighlight()
    self:SetScript("OnUpdate", nil)
    
    local xpos, ypos = GetCursorPosition()
    local xmin, ymin = Minimap:GetLeft(), Minimap:GetBottom()
    xpos = xpos / UIParent:GetScale() - xmin - (Minimap:GetWidth() / 2)
    ypos = ypos / UIParent:GetScale() - ymin - (Minimap:GetHeight() / 2)
    local angle = math.deg(math.atan2(ypos, xpos))
    
    if type(BossKillTimesSettings) == "table" then
        BossKillTimesSettings.minimapAngle = angle
    end
end)

minimapBtn:SetScript("OnClick", function(self, button)
    if button == "RightButton" then
        isMinimapLocked = not isMinimapLocked
        if type(BossKillTimesSettings) == "table" then
            BossKillTimesSettings.isLocked = isMinimapLocked
        end
        
        if isMinimapLocked then
            print("|cFF00FFFF[Boss Kill Times]|r Minimap button |cFFFF0000LOCKED|r.")
        else
            print("|cFF00FFFF[Boss Kill Times]|r Minimap button |cFF00FF00UNLOCKED|r.")
        end
        
        if GameTooltip:GetOwner() == self then
            self:GetScript("OnEnter")(self)
        end
    else
        if BossKillTimesUI and BossKillTimesUI:IsShown() then
            BossKillTimesUI:Hide()
        elseif BossKillTimesUI then
            BossKillTimesUI:Show()
        end
    end
end)

minimapBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Boss Kill Times")
    GameTooltip:AddLine("Left-Click to open UI", 1, 1, 1)
    
    if isMinimapLocked then
        GameTooltip:AddLine("Right-Click to Unlock", 1, 0.5, 0)
        GameTooltip:AddLine("Status: Locked", 1, 0, 0)
    else
        GameTooltip:AddLine("Right-Click to Lock", 1, 0.5, 0)
        GameTooltip:AddLine("Drag to move", 1, 1, 1)
        GameTooltip:AddLine("Status: Unlocked", 0, 1, 0)
    end
    GameTooltip:Show()
end)

minimapBtn:SetScript("OnLeave", function(self)
    GameTooltip:Hide()
end)