@echo off
echo Updating Boss Kill Times from Warmane Armory...
echo ------------------------------------------------
python update_boss_kills.py
echo ------------------------------------------------
pause