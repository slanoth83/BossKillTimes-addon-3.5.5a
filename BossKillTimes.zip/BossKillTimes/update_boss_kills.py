from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import time
from datetime import datetime

# Bossien perusosoitteet
BOSS_URLS = {
    "Anub'Rekhan": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Anub'Rekhan",
    "Grand Widow Faerlina": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Grand%20Widow%20Faerlina",
    "Maexxna": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Maexxna",
    "Noth the Plaguebringer": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Noth%20the%20Plaguebringer",
    "Heigan the Unclean": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Heigan%20the%20Unclean",
    "Loatheb": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Loatheb",
    "Patchwerk": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Patchwerk",
    "Grobbulus": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Grobbulus",
    "Gluth": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Gluth",
    "Thaddius": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Thaddius",
    "Instructor Razuvious": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Instructor%20Razuvious",
    "Gothik the Harvester": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Gothik%20the%20Harvester",
    "The Four Horsemen": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/The%20Four%20Horsemen",
    "Sapphiron": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Sapphiron",
    "Kel'Thuzad": "https://armory.warmane.com/pveladder/Onyxia/Naxxramas/Kel'Thuzad",
    "Sartharion": "https://armory.warmane.com/pveladder/Onyxia/The%20Obsidian%20Sanctum/Sartharion",
    "Malygos": "https://armory.warmane.com/pveladder/Onyxia/The%20Eye%20of%20Eternity/Malygos",
    "Archavon the Stone Watcher": "https://armory.warmane.com/pveladder/Onyxia/Vault%20of%20Archavon/Archavon%20the%20Stone%20Watcher"
}

# Suodattimet eri raideille
MODES = {
    "10m": "?criteria%5B%5D=&criteria%5B%5D=10m",
    "25m": "?criteria%5B%5D=&criteria%5B%5D=25m"
}

OUTPUT_FILE = "Data.lua"

def update_lua_file():
    print("Starting browser engine. Scanning 36 pages (10-man & 25-man), please wait...")
    
    boss_data = {
        "10m": {"Bosses": {}},
        "25m": {"Bosses": {}}
    }

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            page = browser.new_page()
            
            for mode, suffix in MODES.items():
                print(f"\n--- Fetching {mode} data ---")
                for boss, base_url in BOSS_URLS.items():
                    print(f"Fetching {mode} data for: {boss}...")
                    boss_data[mode]["Bosses"][boss] = []
                    
                    full_url = base_url + suffix
                    page.goto(full_url)
                    
                    try:
                        page.wait_for_selector("table tr td", timeout=10000)
                    except:
                        print(f"  -> Timeout or No Data for {boss} ({mode}).")
                        continue
                    
                    added_count = 0
                    seen_ranks = set()
                    
                    for page_num in range(1, 3):
                        html_content = page.content()
                        soup = BeautifulSoup(html_content, 'html.parser')
                        
                        tables = soup.find_all('table')
                        if not tables:
                            break
                        
                        data_table = max(tables, key=lambda t: len(t.find_all('tr')))
                        rows = data_table.find_all('tr')[1:] 
                        
                        for row in rows:
                            if added_count >= 100:
                                break
                                
                            cols = row.find_all('td')
                            
                            if len(cols) >= 3:
                                col_texts = [c.text.strip() for c in cols]
                                
                                rank = col_texts[0]
                                guild = col_texts[1]
                                
                                if rank in seen_ranks:
                                    continue
                                seen_ranks.add(rank)
                                
                                time_val = "Unknown"
                                date_val = "Unknown"
                                
                                for text in col_texts:
                                    text_lower = text.lower()
                                    if ":" in text and len(text) < 10 and not any(char.isalpha() for char in text):
                                        time_val = text
                                    elif "ago" in text_lower or "days" in text_lower or "months" in text_lower or "years" in text_lower or "-" in text_lower:
                                        date_val = text
                                
                                if time_val == "Unknown" and len(col_texts) > 3: time_val = col_texts[3]
                                if date_val == "Unknown" and len(col_texts) > 4: date_val = col_texts[4]

                                boss_data[mode]["Bosses"][boss].append({
                                    "rank": rank,
                                    "guild": guild,
                                    "time": time_val,
                                    "date": date_val
                                })
                                added_count += 1
                        
                        if added_count >= 100 or len(rows) < 50:
                            break
                            
                        try:
                            next_link = None
                            for selector in [".paginate_button.next", "a:text-is('Next')", "a:text-is('2')", "li.next a"]:
                                el = page.locator(selector).first
                                if el.is_visible():
                                    next_link = el
                                    break
                                    
                            if next_link:
                                next_link.click(timeout=3000)
                                page.wait_for_timeout(2000) 
                            else:
                                break 
                        except Exception as e:
                            break
                            
                    time.sleep(1) 
                
            browser.close()
            
    except Exception as e:
        print(f"Error during scraping: {e}")

    print("Converting data to Lua format...")
    
    current_date = datetime.now().strftime("%d/%m/%Y")
    
    lua_content = f'BossKillTimesLastUpdated = "{current_date}"\n'
    lua_content += "BossKillTimesDB = {\n"
    
    total_added = 0
    for mode in ["10m", "25m"]:
        lua_content += f'    ["{mode}"] = {{\n'
        lua_content += '        ["Bosses"] = {\n'
        for boss, kills in boss_data[mode]["Bosses"].items():
            if kills:
                total_added += 1
                lua_content += f'            ["{boss}"] = {{\n'
                for kill in kills:
                    lua_content += f'                {{ rank = "{kill["rank"]}", guild = "{kill["guild"]}", time = "{kill["time"]}", date = "{kill["date"]}" }},\n'
                lua_content += '            },\n'
        lua_content += '        }\n'
        lua_content += '    },\n'
        
    lua_content += "}\n"

    try:
        with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
            f.write(lua_content)
        print("------------------------------------------------")
        print(f"Success! Data.lua completely updated with 10m & 25m data.")
    except IOError as e:
        print(f"Error writing to file: {e}")

if __name__ == "__main__":
    update_lua_file()